import 'package:bmi_app/screens/firstpage.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(home: FirstPage()));
}
