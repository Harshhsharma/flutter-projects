import 'package:flutter/material.dart';
import 'package:netflix_clown/screen/bottomnav.dart';


void main() {
  runApp(MaterialApp(home: NavBar() ,));
}

