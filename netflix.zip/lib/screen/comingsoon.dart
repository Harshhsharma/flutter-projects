import 'package:flutter/material.dart';

class ComingSoon extends StatelessWidget {
  const ComingSoon({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: Icon(
          Icons.arrow_back,
          size: 30,
        ),
        title: Text(
          "Profile & More",
          style: TextStyle(
              fontSize: 25, fontWeight: FontWeight.w400, color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Container(
          color: Colors.black,
          child: Column(
            children: [ 
              // Icon(
              //   Icons.edit,
              //   size: 30,
              //   color: Colors.white,
              // ),
              Center(
                  child: Padding(
                    padding: const EdgeInsets.all(60.0),
                    child: Text(
                                  "Manage profile",
                                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.white,
                      fontWeight: FontWeight.w500),
                                ),
                  )),
                  Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                    height: 50,
                    width: 350,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 37, 39, 37),
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.notifications,color: Colors.white,),
                          // Image.asset(
                          //   'assets/apple.jpg',
                          // ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            'Notification',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                                  ),
                                ],
                              ),
                  ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                 mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 50,
                    width: 350,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 37, 39, 37),
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.list,color: Colors.white,),
                          // Image.asset(
                          //   'assets/apple.jpg',
                          // ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            'My List',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 50,
                    width: 350,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 37, 39, 37),
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.settings,color: Colors.white,),
                          // Image.asset(
                          //   'assets/apple.jpg',
                          // ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            "App Setting",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
           Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 50,
                    width: 350,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 37, 39, 37),
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.account_box,color: Colors.white,),
                          // Image.asset(
                          //   'assets/apple.jpg',
                          // ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            "Account",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 50,
                    width: 350,
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 37, 39, 37),
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Icon(Icons.info,color: Colors.white,),
                          // Image.asset(
                          //   'assets/apple.jpg',
                          // ),
                          SizedBox(
                            width: 15,
                          ),
                          Text(
                            "Help",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 150,
              width: 150,
              color: Colors.black,
              child: Center(child: Text("Sign Out",style: TextStyle(fontSize: 20,color: Colors.white,fontWeight: FontWeight.w400),)),
              
            )
           
                
            ],
          ),
        ),
      ),
    ));
  }
}
