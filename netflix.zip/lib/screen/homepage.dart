import 'package:flutter/material.dart';
import 'package:netflix_clown/shared/widgets/mylist.dart';
import 'package:netflix_clown/shared/widgets/nf_stack.dart';
import 'package:netflix_clown/shared/widgets/preview.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        leading: Image.asset("assets/netflix_logo0.png"),
        actions: [
          Padding(
            padding: EdgeInsets.all(17.0),
            child: GestureDetector(
              onTap: () {
                print("MOV IS CALLED");
              },
              child: Text(
                "TV Shows",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(17.0),
            child: GestureDetector(
              onTap: () {
                print("mov is called");
              },
              child: Text(
                "Movies",
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(17.0),
            child: Text(
              "My List",
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w400),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          color: Color.fromARGB(255, 5, 5, 5),
          width: double.infinity,
          // height: double.infinity,
          child: const Column(
            children: [
              NFSTACK(),
              PREVIEW(),
              MYLIST(),
            ],
          ),
        ),
      ),
    ));
  }
}
