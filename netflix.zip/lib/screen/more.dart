import 'package:flutter/material.dart';
import 'package:netflix_clown/shared/widgets/morestack.dart';
import 'package:netflix_clown/shared/widgets/recently.dart';

class More extends StatelessWidget {
  const More({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text("  Games",style: TextStyle(fontSize: 25,fontWeight: FontWeight.w400)),
        actions:  [
            Icon(Icons.search),
            SizedBox(
              width: 10,
            ),
         Padding(
           padding: const EdgeInsets.all(12.12),
           child: Container(
            child: Image.asset("assets/sintel.jpg"),
            
           ),
         ),SizedBox(
          width: 20,
         )
          ],
          
      ),
      body: SingleChildScrollView(
        child: Container( 
          color: Color.fromARGB(255, 11, 11, 11),
          width: double.infinity,
          // height: double.infinity,
          child: Column(
            children: [ 
              MORESTACK(),
              RECENTLY()
     // Image.asset("assets/black_mirror.jpg"),
            ],
          ),
        ),
      ),)
    );
  }
}