import 'package:flutter/material.dart';

class MORESTACK extends StatelessWidget {
  const MORESTACK({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image.asset("assets/black_mirror.jpg"),
        Positioned(
          bottom: 100,
          right: 140,
          child: Row(
            children: [
              Icon(
                Icons.play_arrow,
                color: Colors.white,
                size: 50,
              ),
              Text(
                "Play",
                style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              )
            ],
          ),
        )
      ],
    );
  }
}
