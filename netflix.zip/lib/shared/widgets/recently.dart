import 'package:flutter/material.dart';

class RECENTLY extends StatelessWidget {
  const RECENTLY({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.all(10.0),
        child: Text(
          "Recently Released",
          style: TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      Container(
        width: double.infinity,
        height: 200,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: [
            Container(
              width: 130,
              height: 2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(
                      'assets/sintel.jpg'),
                  fit: BoxFit.cover,
                ),
                // width: 110,
                // height: 100,
                // child: Image.asset("assets/thirteen_reasons.jpg"),
              ),
            ),
            Container(
              width: 130,
              height: 2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(
                      'assets/carole.jpg'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
                // width: 110,
                // height: 100,
                // child: Image.asset("assets/thirteen_reasons.jpg"),
              ),
            ),
            Container(
              width: 130,
              height: 2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(
                      'assets/crown.jpg'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
                // width: 110,
                // height: 100,
                // child: Image.asset("assets/thirteen_reasons.jpg"),
              ),
            ),
            Container(
              width: 130,
              height: 2,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  image: AssetImage(
                      'assets/thirteen_reasons.jpg'), // Replace with your image path
                  fit: BoxFit.cover,
                ),
                // width: 110,
                // height: 100,
                // child: Image.asset("assets/thirteen_reasons.jpg"),
              ),
            )
          ],
        ),
      )
    ]);
  }
}
