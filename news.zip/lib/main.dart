import 'package:flutter/material.dart';
import 'package:news/screens/homepage.dart';

void main() {
  runApp(MaterialApp(home: HomePage(),));
}

