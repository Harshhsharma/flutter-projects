// import 'dart:js';

import 'package:flutter/material.dart';
import 'package:sangeet/screens/home.dart';
import 'package:sangeet/screens/homeScreen.dart';
import 'package:sangeet/screens/loadingScreen.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner:false,
//    home: const LoadingScreen(),
    // theme:  ThemeData.dark(),
    initialRoute: '/',
    routes: {
      '/':(context)=> const LoadingScreen(),
      '/home': (context)=> const HomePage(),
      '/home2': (context)=> const Home()
    },
  ));
}