import 'package:flutter/material.dart';
//import 'package:sangeet/screens/player.dart';
import 'package:sangeet/shared/widgets/stack.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(appBar:AppBar(
        backgroundColor: Colors.black,
        leading: Icon(Icons.notifications),
        title: Row(children: [Chip(label: Text("MUSIC")),
        SizedBox(width: MediaQuery.of(context).size.width*0.1,),
        Chip(label: Text("PODCAST"))],),
        centerTitle: true,
        actions: [ Icon(Icons.settings)],
      ),
      body: Column(
        children: [
          Row(children: [ Text("Trending Playlist",style: TextStyle(fontSize:20,color: Colors.black),),
          
          Spacer(),
          Chip(label: Text("SEE MORE"))
          ],),
          SizedBox(
            height: MediaQuery.of(context).size.height*0.25,
            child: ListView(children: [
              SongStack(),
              SongStack(),
              SongStack(),
            ]),
          )
        ],
      ),
      
      ),

    );
  }
}