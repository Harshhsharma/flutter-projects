import 'dart:convert';

import 'package:dio/dio.dart';

class SongClient {
  final Dio _dioClient = Dio();
  getSongsFromITunes( String singerName) async {
    try {
      String iTunesUrl =
          "https://itunes.apple.com/search?term=$singerName&limit=25";
      var res = await _dioClient.get(iTunesUrl);
      Map<String, dynamic> songsMap = jsonDecode(res.data);
      print("this is the response $res");
      return songsMap;
    } catch (error) {
      print("some error has occured in song $error");
    }
  }
}
