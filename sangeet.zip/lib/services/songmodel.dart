class SongModel {
  late String artistName;
  late String trackName;
  late String artworkUrl100;
  late String previewUrl;
  bool isPlaying = false;

  // ignore: avoid_types_as_parameter_names
  SongModel({
    required this.artistName,
    required this.trackName,
    required this.artworkUrl100,
    required this.previewUrl,
     required this.isPlaying,
  });

  SongModel.fromJSON(Map<String, dynamic> jsonMap) {
    artistName = jsonMap['artisName'] ?? "not avl";
    trackName = jsonMap['trackName'] ?? "not avl";
    artworkUrl100 = jsonMap['artworkUrl100'] ?? "not avl";
    previewUrl = jsonMap['previewUrl'] ?? "not avl";
  }
}
