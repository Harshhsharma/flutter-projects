import 'package:flutter/material.dart';
import 'package:yt/screens/homePage.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    ),
  );
}
